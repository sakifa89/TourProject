-- phpMyAdmin SQL Dump
-- version 2.11.7
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jan 22, 2017 at 09:34 AM
-- Server version: 5.0.51
-- PHP Version: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `air`
--

-- --------------------------------------------------------

--
-- Table structure for table `air1`
--

CREATE TABLE IF NOT EXISTS `air1` (
  `source` varchar(20) NOT NULL,
  `destination` varchar(20) NOT NULL,
  `name` varchar(30) NOT NULL,
  `details` varchar(10000) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `air1`
--

INSERT INTO `air1` (`source`, `destination`, `name`, `details`) VALUES
('rajshahi Rajshahi ', ' dhaka Dhaka', 'Hanif travel ', '');
