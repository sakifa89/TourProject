-- phpMyAdmin SQL Dump
-- version 2.11.7
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jan 22, 2017 at 09:34 AM
-- Server version: 5.0.51
-- PHP Version: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `fireinfo`
--

-- --------------------------------------------------------

--
-- Table structure for table `fire`
--

CREATE TABLE IF NOT EXISTS `fire` (
  `id` int(11) NOT NULL auto_increment,
  `keywords` varchar(100) NOT NULL,
  `description` varchar(10000) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `fire`
--

INSERT INTO `fire` (`id`, `keywords`, `description`) VALUES
(1, 'head quarter', '<center><h2>Head Quarter:  Telephone: 9555555, 9556667</h2><br>  <h4>Emergency:      Telephone: 199</h4></center>'),
(2, 'sadarghat dhaka', '<center><h2>Sadarghat Fire Service : Tel: 7119759</h2></center>'),
(3, 'dhaka ', '<center>  <h2>Pastogola Fire Service  : Tel: 7440771</h2><br>  <h2>Lalbagh Fire Service    : Tel: 8619981</h2><br>  <h2>Khigaon Fire Service   : Tel: 7218329</h2><br>  <h2>Tejgaon Fire Service    : Tel: 9898187</h2><br>  <h2>Mohammedpur Fire  Service                         : Tel: 9112078</h2><br>  <h2>Mirpur Fire Service      : Tel: 9001055</h2><br>  <h2>Kurmitola Fire Service : Tel: 8713399</h2><br>  <h2>Tongi Fire Service        : Tel: 9801070</h2><br>  <h2>Palashi Fire Service      : Tel: 8628688</h2><br> </center>');
