-- phpMyAdmin SQL Dump
-- version 2.11.7
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jan 22, 2017 at 09:35 AM
-- Server version: 5.0.51
-- PHP Version: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `loginplane`
--

-- --------------------------------------------------------

--
-- Table structure for table `planeinfo`
--

CREATE TABLE IF NOT EXISTS `planeinfo` (
  `code` int(20) NOT NULL auto_increment,
  `seat` varchar(20) NOT NULL,
  `departing` varchar(20) NOT NULL,
  `arival` varchar(20) NOT NULL,
  `ticketfare` varchar(20) NOT NULL,
  `startairport` varchar(100) NOT NULL,
  `endairport` varchar(100) NOT NULL,
  `name` varchar(50) NOT NULL,
  `available` varchar(20) NOT NULL,
  PRIMARY KEY  (`code`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=24 ;

--
-- Dumping data for table `planeinfo`
--

INSERT INTO `planeinfo` (`code`, `seat`, `departing`, `arival`, `ticketfare`, `startairport`, `endairport`, `name`, `available`) VALUES
(1, '100', '12:30 PM', '01:30 PM', '4000', 'Dhaka', 'Cox''s Bazer', 'US-BANGLA AIRLINES', '10'),
(2, '150', '07:30 AM', '08:20 AM', '3000', 'Dhaka', 'Chittagong', 'US BANGLA AIRLINES', '5'),
(3, '150', '10:00 AM', '10:50 AM', '3000', 'Dhaka', 'Chittagong', 'US BANGLA AIRLINES', '4'),
(4, '150', '03:15 PM', '04:05 PM', '3000', 'Dhaka', 'Chittagong', 'US BANGLA AIRLINES', '10'),
(5, '120', '08:40 AM', '09:30 AM', '3000', 'Chittagong', 'Dhaka', 'US BANGLA AIRLINES', '20'),
(6, '120', '04:25 PM', '05:15 PM', '3000', 'Chittagong', 'Dhaka', 'US BANGLA AIRLINES', '10'),
(7, '100', '11:35 AM', '12:35 PM', '4000', 'Cox''s Bazer', 'Dhaka', 'US BANGLA AIRLINES', '10'),
(8, '100', '12:30 PM', '01:30 PM', '4000', 'Dhaka', 'Cox''s Bazer', 'US BANGLA AIRLINES', '8'),
(9, '150', '10:15 AM', '11:15 AM', '4000', 'Dhaka', 'Cox''s Bazer', 'US BANGLA AIRLINES', '15'),
(10, '100', '07:40 AM', '08:20 AM', '4000', 'Dhaka', 'Jeossor', 'BIMAN BANGLADESH AIRLINES', '10'),
(11, '100', '05:40 PM', '06:20 PM', '3500', 'Dhaka', 'Jeossor', 'US BANGLA AIRLINES', '10'),
(12, '100', '08:35 AM', '09:15 AM', '3500', 'Jeossor', 'Dhaka', 'US BANGLA AIRLINES', '13'),
(13, '100', '06:40 PM', '07:20 PM', '3500', 'Jeossor', 'Dhaka', 'BIMAN BANGLADESH AIRLINES', '10'),
(14, '100', '01:00 PM', '01:40 PM', '3000', 'Dhaka', 'Sylhet', 'US BANGLA AIRLINES', '10'),
(15, '100', '02:00 PM', '02:40 PM', '3000', 'Sylhet', 'Dhaka', 'US BANGLA AIRLINES', '10'),
(16, '100', '09:40 AM', '10:30 AM', '3000', 'Dhaka', 'Saidpur', 'US BANGLA AIRLINES', '20'),
(17, '100', '03:30 PM', '04:20 PM', '3000', 'Dhaka', 'Saidpur', 'US BANGLA AIRLINES', '25'),
(18, '100', '10:50 AM', '11:40 AM', '3000', 'Saidpur', 'Dhaka', 'US BANGLA AIRLINES', '10'),
(19, '100', '04:35 PM', '05:25 PM', '3000', 'Saidpur', 'Dhaka', 'US BANGLA AIRLINES', '15'),
(20, '99', '12:00 PM', '12:40 PM', '2900', 'Dhaka', 'Rajshahi', 'US BANGLA AIRLINES', '20'),
(21, '99', '01:00 PM', '01:40 PM', '2900', 'Rajshahi', 'Dhaka', 'US BANGLA AIRLINES', '20'),
(22, '100', '12:00 PM', '12:30 PM', '4000', 'Dhaka', 'Barisal', 'US BANGLA AIRLINES', '10'),
(23, '100', '12:50 PM', '01:20 PM', '4000', 'Barisal', 'Dhaka', 'US BANGLA AIRLINES', '20');
