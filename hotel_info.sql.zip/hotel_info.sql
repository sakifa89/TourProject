-- phpMyAdmin SQL Dump
-- version 2.11.7
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jan 22, 2017 at 09:35 AM
-- Server version: 5.0.51
-- PHP Version: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `hotel_info`
--

-- --------------------------------------------------------

--
-- Table structure for table `hotel`
--

CREATE TABLE IF NOT EXISTS `hotel` (
  `Place` varchar(1000) NOT NULL,
  `Unit` varchar(1000) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `hotel`
--

INSERT INTO `hotel` (`Place`, `Unit`) VALUES
('Parjatan Holiday Complex Cox’s Bazar.  Fax: 0341-64202Restaurant Capacity- 130', 'Hotel Shaibal (0341-63274) AC Twin Bed  AC Royal Suite (Couple Bed)  Standard Twin Bed  Conference Hall (100 p)      All Rooms: TV, TEL, HOT&COLD WATER, MINI FRIDGE Cottage: Per cottage 1 AC room (Couple bed), 1Non AC Twin bed, Drawing room, Drivers room, Dining  & Kitchen facility)'),
('Parjatan Motel Probal Cox’s Bazar  Restaurant Capacity-80', 'Motel Probal (0341 -63211) AC Couple Bed/Twin Bed                Non AC Twin Bed/Couple Bed  Economy Room (Twin Bed)  Conference Hall (50-60) NAC Per day All rooms:TV, TEL, HOT&COLD WATER Dormetory (8 bed) 20 Person 30 Person 40 Person 50+ Person'),
('Parjatan Motel  UpalCox’s Bazar', 'Motel Upal (0341-64258) Non AC Twin Bed TV, Tele,Hot & Cold water  AC Twin Bed Mini Fridge, TV,Tele,Hot & Cold water  Dormitory Bed (per bed)'),
('Chittagong Railway Station', 'Motel Shaikat (031-611046, 611047)  Non AC Twin Bed  AC Twin Bed'),
('Parjatan Holiday Complex Rangamati  Bar Capacity- 14 Restaurant Capacity- 32', 'Parjatan Motel (0351-63126, 61046) Non AC Twin Bed –TV   AC Twin Bed – TV,TEL,HOT&COLD WATER Tribal Honeymoon cottage -1 (per room) 1 d bed, 1 s bed TV, Tel Full cottage  Tribal Honeymoon cottage -2 (Exclusive cottage)'),
('Mongla     Restaurant Capacity-50', 'Parjatan Hotel Pashur (04662-75100)  Non AC Twin Bed –TEL,HOT&COLD WATER AC Twin Bed – TV,TEL,HOT&COLD WATER'),
('Parjatan Motel RangpurFax: 0521-62894      Restaurant Capacity-50', 'Parjatan Motel Rangpur  (0521-63681) Non AC Twin Bed – TEL,HOT& COLD WATER AC Deluxe –TEL,TV,HOT& COLD WATER VIP AC Suite-FRIDGE,TEL,TV, HOT&COLD Economy Bed  AC C. Hall (150) (First Two Hours)   (Next Per Hour)'),
('Bogra Fax: 051-66753    Restaurant Capacity-60', 'Parjatan Motel Bogra (051-67024-27) Non AC Twin Bed TEL,HOT& COLD WATER AC Twin Bed TEL,HOT& COLD WATER AC Suite  Drivers Bed  AC Conf. Hall (350) (Full Day)  next per hour Mini Confe. (30)'),
('Sylhet  Phone: 0821-712426 Restaurant Capacity-60', 'Parjatan Motel (0821-712426) Non AC Twin Bed  AC Twin Bed with T.V.  Conference Hall (Full Day)  (Half Day)'),
('Meherpur', 'Parjatan Motel Muzibnagore AC Suite Room AC Deluxe Room Non AC Room Con. Hall (100 Pers.) (Full Day) (Half Day)'),
('Dinajpur   Restaurant Capacity-30', 'Parjatan Motel  (0531-64718) AC Twin Bed (1st floor)  AC Deluxe Twin Bed (2nd floor)  AC Deluxe Twin Bed (3rd  floor)  Economy Bed  All Rooms: TV, TEL, HOT & COLD WATER Conference Hall (Full Day)  (Half Day)'),
('Rajshahi Fax: 0721-775237  Restaurant Capacity-50', 'Parjatan Motel (0721 -775492)   AC Single Bed AC Twin Bed  VIP Suite Drivers Bed  AC Conference Hall  (100 Pers.)  First two hour Next per hour AC Mini Conference Hall  (25 Pers.)  Per hour NonAC Conference Hall  (50 Pers.)  Full/Half day'),
('Holiday Homes Kuakata   Restaurant Capacity -50', 'Parjatan Motel (04428-56004) AC Double Bed (Deluxe)-TV, TEL, HOT & COLD WATER AC Twin Bed – TV, TEL Non AC Twin Bed – TV Economy Room  Conference Hall (50 Pers.)'),
('Youth in Kuakata', 'NON AC Four Bed NON AC Twin Bed AC TWIN Bed Royal Suite room Conference Hall'),
('Tungipara   Restaurant Capacity-50', 'Parjatan Motel (06655-56349) Non AC Twin Bed  AC Twin Bed  Dormitory (Each room 4 bed)'),
('TeknafHotel Ne-Taung     Restaurant Capacity -50', 'Hotel Ne-Taung (03426-75104) Non Ac Twin Bed –HOT& COLD WATER,.TEL  Ac Twin Bed HOT,& CLOD WATER,TEL,TV  Ac Suite Room'),
('Parjatan Motel  Khagrachhari Restaurant Capacity -50', 'Khagrachhari & Amusement Centre(0371-62084-85) Non AC Twin Bed TV, TEL AC Twin Bed TV, TEL, HOT & COLD WATER AC Suite Room TV, TEL, HOT & COLD WATER Economy Room Conference Hall (100 Pers.) (Full day) (Half day)'),
('Parjatan Motel Benapole    01716984262    Restaurant Capacity -50', 'Motel Benapole (04228-75411)  Non AC Twin Bed  AC Twin Bed  AC Suite Room  Dormitory (Per Room-4 Bed) Per bed All Rooms: TV, TEL, HOT & COLD WATERConference Hall   (1st two hour) (Next per hour)'),
('Hotel Abakash Dhaka Tel: 8811109 9899288 9899290 Fax: 8811150', 'Restaurant Capacity-100 AC Twin Deluxe-TV, TEL ,FRIDGE, HOT & COLD AC Twin Standard  AC Conference Hall (Capacity-40 Pers.) (Full day) (Half day) Banquet Hall (150 Pers.)  (Full day) (Half day)');

-- --------------------------------------------------------

--
-- Table structure for table `hotelfive`
--

CREATE TABLE IF NOT EXISTS `hotelfive` (
  `location` varchar(25) NOT NULL,
  `hotel_name` varchar(25) NOT NULL,
  `address` varchar(100) NOT NULL,
  `cell_no` varchar(20) NOT NULL,
  `email` varchar(30) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `hotelfive`
--

INSERT INTO `hotelfive` (`location`, `hotel_name`, `address`, `cell_no`, `email`) VALUES
('Dhaka', 'Pan Pacific Sonargaon Hot', '107 , Kazi Nazrul Islam Avenue', '880 2 811 1005', 'Pan Pacific Sonargaon Hotel, D'),
('Airport Road,Dhaka', 'Radisson Water Garden Hot', 'Airport Road, Dhaka Cantonment, Dhaka 1206 Banglades', '+ 88 02 8754555', 'reservations.dhaka@radisson.co'),
('Gulshan,Dhaka', 'the westin hotel', 'Main Gulshan Avenue, Gulshan Ave, Dhaka 1212	', '01755642202', 'munirul.kabir@westin.com'),
('Banani, Dhaka', 'Hotel sarina', 'Plot#27, Road#17, Bir UttamAminul Haque Sarak,', '982112, 02-8851011', 'www.sarinahotel.com'),
('Nikunjo, Dhaka', 'DHAKA REGENCY HOTEL & RES', 'Airport Road,khilkhet, Front Road, Dhaka', '88 01713332651-54', 'INFO@DHAKAREGENCY.COM'),
('Cox’s Bazar,', 'Seagull Hotel Ltd', 'Hotel Motel Zone ,Cox’s Bazar Sea Beach,Cox’s Bazar', '01766666537 Ph 03416', 'reservations@seagullhotelbd.co'),
('Cox''s Bazar', 'Ocean Paradise Hotel and ', '28-29,Hotel Motel Zone,Kolatoli,Cox''s Bazar', 'Ph: 034152370', 'reservation@oceanparadisehotel');
