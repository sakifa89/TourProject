-- phpMyAdmin SQL Dump
-- version 2.11.7
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jan 22, 2017 at 09:36 AM
-- Server version: 5.0.51
-- PHP Version: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `logintrain`
--

-- --------------------------------------------------------

--
-- Table structure for table `traininfo`
--

CREATE TABLE IF NOT EXISTS `traininfo` (
  `code` int(11) NOT NULL auto_increment,
  `seat` varchar(20) NOT NULL,
  `departing` varchar(20) NOT NULL,
  `arival` varchar(20) NOT NULL,
  `ticketfare` varchar(20) NOT NULL,
  `startstation` varchar(20) NOT NULL,
  `endstation` varchar(20) NOT NULL,
  `name` varchar(20) NOT NULL,
  `availabel` varchar(10) NOT NULL,
  PRIMARY KEY  (`code`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=705 ;

--
-- Dumping data for table `traininfo`
--

INSERT INTO `traininfo` (`code`, `seat`, `departing`, `arival`, `ticketfare`, `startstation`, `endstation`, `name`, `availabel`) VALUES
(4, '1000', '07:00', '02.00', '300', 'Rajshahi', 'Dhaka', 'Slik-city', '10'),
(701, '1000', '07:00 AM', '12:40 PM', '320', 'Chittagong', 'Dhaka', 'Subarna Express Trai', '30'),
(702, '1000', '15:00', '21:30', '320', 'Dhaka', 'Chittagong', 'Subarna Express Trai', '10'),
(703, '1000', '15:00', '22:15', '320', 'Chittagong', 'Dhaka', 'Mohanagar Goduli', '10'),
(704, '1000', '7:45', '14:55', '320', 'Dhaka', 'Chittagong', 'Mohanagar Provati', '20');
