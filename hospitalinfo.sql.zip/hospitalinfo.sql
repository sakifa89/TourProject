-- phpMyAdmin SQL Dump
-- version 2.11.7
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jan 22, 2017 at 09:35 AM
-- Server version: 5.0.51
-- PHP Version: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `hospitalinfo`
--

-- --------------------------------------------------------

--
-- Table structure for table `hospital`
--

CREATE TABLE IF NOT EXISTS `hospital` (
  `id` int(11) NOT NULL,
  `keywords` varchar(100) NOT NULL,
  `description` mediumtext NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `hospital`
--

INSERT INTO `hospital` (`id`, `keywords`, `description`) VALUES
(1, 'dmc DMC dhaka medical', '<br><br><center><h3>Dhaka Medical College Hospital</h3>\r\n\r\n<h3>Tel : 8626812-26, 8626818-25</h3><br></center>'),
(2, 'pg hospital shahabagh dhaka', '<center><h3>PG Hospital (BSMMU)</h3>\r\n\r\n<h3>Shahabagh, Dhaka. Tel: 8612550, 8614545-9, 9661900-59</h3><br></center>\r\n'),
(3, 'salimullah midford dhaka', '<center>\r\n<h3>Sir Salimullah Medical College Hospital</h3>\r\n\r\n<h3>Midford, Dhaka – 1100. Tel: 7310061-4, 7319002-6</h3><br></center>'),
(4, 'eskaton dhaka', '<center>\r\n<h3>Holy Family Hospital</h3>\r\n\r\n<h3>Eskaton Garden, Tel: 8311721-25, 8321721-24</h3><br>\r\n\r\n </center>'),
(5, 'shishu child hospital agargaon dhaka', '<center>\r\n<h3>Shishu Hashpatal</h3>\r\n\r\n<h3>(Child Hospital) Shre-E-Bangla Nagar, Agargaon, Dhaka.</h3>\r\n\r\n<h3>Tel: 9119119, 8116061-2</h3></center>'),
(6, 'diabetic shahbagh dhaka', '<center>\r\n<h3>BIRDEM (Diabetic Hospital)</h3>\r\n\r\n<h3>Shahabagh. Tel: 9661551-60,8616641-50</h3><br>\r\n\r\n </center>'),
(7, 'eye hospital ', '<center><h3>Lion eye Hospital</h3>\r\n\r\n<h3>Tel: 9112927</h3><br></center>'),
(8, 'orthopadic hospital', '<center>\r\n<h3>Orthopadic Hospital</h3>\r\n\r\n<h3>Tel: 91 14075, 91 12150</h3><br>\r\n</center>\r\n ');
