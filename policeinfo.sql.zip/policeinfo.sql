-- phpMyAdmin SQL Dump
-- version 2.11.7
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jan 22, 2017 at 09:36 AM
-- Server version: 5.0.51
-- PHP Version: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `policeinfo`
--

-- --------------------------------------------------------

--
-- Table structure for table `police`
--

CREATE TABLE IF NOT EXISTS `police` (
  `id` varchar(1000) NOT NULL,
  `keywords` varchar(1000) NOT NULL,
  `description` varchar(10000) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `police`
--

INSERT INTO `police` (`id`, `keywords`, `description`) VALUES
('1', 'dhaka metropoliton', '<center> <h2>Police Station</h2. <center> <h2>Dhaka Metropoliton Police (DMP)</h2>  <h3>Emergency Telephone: 999</h3><br>  <h3>Control Room Telephone: 8616552-7, 8616551-3, 8914664</h3><br>  <h3>DC, DB (Detective Branch) Telephone: 9337362</h3><br>  <h3>Head Quarter Telephone: 9667336</h3><br>   </center>'),
('', 'dhaka Dhaka', '<br><center> <h3>Badda Thana (PS)        :           Tel: 9882652</h3><br>  <h3>Cantonment Thana (PS)   :           Tel: 8829267</h3><br>  <h3>Demra Thana (PS)       :           Tel: 7S 16244</h3><br>  <h3>Dhanmondi Thana (PS)    :           Tel: 8631942</h3><br>  <h3>Gulshan Thana (PS)     :           Tel: 9880234</h3><br>  <h3>Hajari bag Thana (PS)  :           Tel: 9669900</h3><br>  <h3>Kafrul Thana (PS)       :           Tel: 9871771</h3><br>  <h3>Kamrangirchar Thana (PS):      Tel: 7320323</h3><br>  <h3>Kotwali Thana (PS)      :           Tel: 71 16255</h3><br>  <h3>Khilgaon Thana (PS)    :           Tel: 7219090</h3><br>  <h3>Lalbagh Thana (PS)     :           Tel: 7316300</h3><br>  <h3>Mohammadpur Thana (PS) :    Tel: 91 19960</h3><br>  <h3>Motijheel Thana (PS)   :           Tel: 8323008</h3><br>  <h3>Pallabi Thana (PS)      :           Tel: 8015 122</h3><br>  <h3>Ramna Thana (PS)       :           Tel: 9350468</h3><br>  <h3>Shabujbag Thana (PS)  :           Tel: 7219988</h3><br>  <h3>Shutrapur Thana (PS)   :           Tel: 7116233</h3><br>  <h3>Shyampur Thana (PS)  :           Tel: 7410691</h3><br>  <h3>Tpjgaon Thana (PS)     :           Tel: 9119444</h3><br>  <h3>Uttara Thana (PS)       :           Tel: 8931888</h3><br>  <h3>Adabor Thana (PS)      :           Tel: 9133265</h3><br>  <h3>Airport Thana (PS)      :           Tel: 8919364</h3><br>  <h3>Dakhin Khan Thana (PS) :        Tel: 8931777</h3><br>  <h3>Jatrabari Thana (PS)    :           Tel: 7546244</h3><br>  <h3>Kerani Ganj Thana (PS)  :           Tel: 7772300</h3><br>  <h3>Khilkhet Thana (PS)    :           Tel: 8919364</h3><br>  <h3>Mirpur Thana (PS)       :           Tel: 9001001</h3><br>  <h3>New Market Thana (PS)   :           Tel: 8631942</h3><br>  <h3>Palton Thana (PS)       :           Tel: 9360802</h3><br>  <h3>Shahbagh Thana (PS)   :           Tel: 9676666</h3><br> </center>');
